from pathlib import Path
import json
p=Path(__file__).parent; data=json.loads((p/'inventory.json').read_text())
# Design proposals only. Nothing in this map changes production mechanics.
proposals={
'golem':('P1','重い踏み込み後に単発の地割れ。動作中は押し戻しに強く、空中には届かない。'),
'slime':('keep','既存の死亡分裂2体を主役にし、親の強さと子の限界を表示する。追加召喚は不要。'),
'spore_toad':('keep','毒雲による持続削りを主役にする。毒の実効12/秒、残り時間、再付与耐性を見せる。'),
'rootwarden_treant':('P2','周囲の味方を射撃から守る防壁役。味方へ届く半径を表示し、自己装甲と区別する。'),
'siege_crab':('P1','狙った地点に遅れて落ちる重い砲撃。着弾前に避けられる固定地点予告を持つ。'),
'frosthorn_rhino':('candidate','氷角で地上の相手を押し戻し、短時間その戻り足を鈍らせる。重量抵抗と解除を残す。'),
' thornback_beast':('keep','既存の接触反撃を主役にする。乱打に強く遠隔には反撃しない弱点を見せる。'),
'basalt_titan':('P2','溜めの長い全周衝撃を、狭い密着範囲での反撃型として強調する。'),
'frostbreath_lizard':('P1','長い溜めの扇状氷息。単体への鈍足とは別に、命中した少数の敵を短く停止させる案を比較する。'),
'cleaver_brute':('P2','前後の薙ぎ払いで別の敵を狙う。二段目は最初の対象が倒れても範囲内別対象へ振れる案。'),
'gauntlet_combo_guard':('P2','初撃が受け止められても最後の拳だけ重い。コンボ終段前の予告と中断条件を明確にする。'),
'shockplate_drake':('keep','既存の二段衝撃を役割として残す。二段目の半径拡大を明確に描く。'),
'thunderhorn_beast':('P2','正面の最初の対象から近隣2体へ跳ぶ雷角。広域ではなく密集に刺さる上限付き連鎖。'),
'roarfang_beast':('P2','短射程の咆哮で敵の次の通常攻撃を一度遅らせる。遅延免疫と連撃中断の扱いを明示する。'),
'emberwing_drake':('P2','飛行したまま地上の狭い扇形を焼く。既存飛行＋ブレスを活かし、対空には弱い役割を明示。'),
'carapace_slashbeast':('P1','一撃準備中に正面からの射撃を一度軽減し、その後に重い単発斬り。攻撃しない無敵化は避ける。'),
'triad_chimera':('P2','連撃の二段目だけ別対象へ向き直る。単体火力より複数相手への対応力を個性にする。'),
'pillar_hammerer':('keep','既存の離れた柱攻撃と密着時の弱い迎撃を保持。柱位置、空振り、密着弱点を見せる。'),
'bluefist_colossus':('P2','拳の前方だけ大きく押し出す。全周攻撃と違って背面へ届かない役割。'),
'cinder_tailbeast':('P2','尾の薙ぎ払い後に一度だけ小さな残り火を残す。設置数と持続時間は厳しく制限する。'),
'razorclaw_reaver':('P2','片爪で一撃、もう片爪で回復阻害。即時火力ではなく回復編成への対策にする。'),
'ringneck_prowler':('P1','伸びる首の一撃後に首を引く。長い接触間合いと反撃を避ける後退を組み合わせる。'),
'bluehorn_invoker':('P2','周囲の衝撃で敵の短い強化を一つ解除する。解除対象の優先順位を固定する。'),
'bonefan_reaper':('P2','扇形の刃で召喚体を優先し、子の群れを刈る。蘇生者を召喚体扱いしない。'),
'flamering_magus':('P2','輪の外縁ほど有効な炎。中心の安全域と予告を持たせ、単なる全周爆発と区別する。'),
'emberfist_pillarer':('P2','前方固定地点の火柱を二段発生。標的追尾ではなく、避けられる時間差攻撃。'),
'moonclaw_werewolf':('P2','二段目に小さな吸収回復。最大HP比の無限再生ではなく実際の与ダメ分から上限付き回復。'),
'spikeburst_grinder':('P2','密着している敵ほど多く当たる棘。対象数上限を守り、射撃相手には追う弱点を残す。'),
'silverarm_vanguard':('P2','近くの味方を一度だけかばってから全周反撃。かばう回数は蘇生しても回復しない。'),
'veteran_flamewing':('P2','初撃命中時にだけ二段目へ炎を上乗せ。外した時は追撃が弱くなる命中条件型。'),
'stormhorn_tripler':('P2','二段目が命中した時だけ短い攻撃遅延。名前と実際の2連撃の不一致も見直す。'),
'spectral_scale_dragon':('P1','初めて受ける直接攻撃を薄い幻鱗で一度だけ減らす。回避乱数ではなく確定の単発防御。'),
'fiery_coil_inceptor':('P2','近接被弾で熱を少数蓄え、次の全周攻撃で使い切る。上限を持つ反撃型。'),
'stonepulse_kolossus':('P2','小さな第一波と遅い外周第二波。範囲が時間で変わる地面の波として区別する。'),
'darkfan_clawlord':('P2','初撃で弱点を付け、次の味方の一撃へ小さく繋ぐ。自身の二段目だけで消費しない条件を検討。'),
'plated_dualdragon':('P2','二段目準備中だけ射撃に強い。常時同じ装甲ではなく守りが切り替わる。'),
'colossal_hornfist':('keep','短い前方柱と密着迎撃という既存の二つの間合いを主役にし、遠い柱役と見分ける。'),
'redhorn_dualbeast':('P2','初撃で押し込み、二段目は届いた時だけ強打。無条件の二連撃との差を作る。'),
'iceclaw_legend':('P2','最も遠い前方敵へ氷の爪。足止めを重ねるのでなく、後列へ届く狭い扇形を差別化する。'),
'cyanrise_silithar':('P2','回転中に引き寄せを受けにくく、終了時に周囲へ反撃。行動中の耐性を明示する。'),
'flameburst_mythron':('P2','大きな一回目の爆発と小さな残響。即発の同形爆発と違う二段予告を持たせる。'),
'accretion_burstcore':('P2','空中から範囲内の地上敵を少し中心へ寄せて爆発。吸引対象数・距離・頻度に上限。'),
'kilnback_pincerbeast':('P1','大きな鋏の一撃で一体を短く固定する。複数拘束や永続拘束はしない。'),
'skullflare_triad':('keep','既存の固定前方円三段という形状を保持し、毎段当たる条件と空振りを見せる。'),
'willyee_frost_dragon':('P2','氷息に被回復量低下を短く付ける。氷角の移動鈍足、リザードの停止とは役割を分ける。'),
'willyee_stone_golem':('P1','最初の重い打撃だけ周囲へ結晶片を飛ばす。以後は単体攻撃として二種のゴーレムを分ける。'),
}
proposals={k.strip():v for k,v in proposals.items()};bosses={r['k'] for r in data if r['t'].get('boss')};assert set(proposals)==bosses,(set(proposals)^bosses)
rows=[]
for r in data:
 t=r['t']; priority,proposal=proposals.get(r['k'],('P3','所属する攻撃・支援系統内で、対象選択、発動条件、対策可能な弱点を比較してから一つだけ独自要素を選ぶ。'))
 if t.get('selfRepairCharges'):priority='P1';proposal={'repair_pylon':'反射＋修復の耐久柱を残し、反射した実ダメージと残り修復回数を示す。','embergrille_monument':'修復と反射の複製から外し、被弾で蓄積した熱を一回だけ範囲放出する案を比較。','eggshell_repairpod':'殴られて自己回復するだけでなく、一回の孵化または割れた時の一体防護へ変える案を比較。'}[r['k']]
 rows.append({'id':r['k'],'name':t['name'],'boss':bool(t.get('boss')),'cost':r['cost'],'current':r['facts'],'reviewPriority':priority,'proposalOnly':proposal,'implementation':'frost-horn candidate evaluated separately' if r['k']=='frosthorn_rhino' else 'not changed'})
(p/'character-review-300.json').write_text(json.dumps({'sourceSHA256':'fe91cc2808610cb6a33f7aa2696aa84c2b4009bb2f70326e7bf2aa14296710a0','warning':'Proposals are not implemented or approved balance changes. All 300 are inventoried; only one candidate has been implemented.','rows':rows},ensure_ascii=False,indent=2)+'\n')
(p/'boss-proposals-46.md').write_text('# 大型46種の方向案\n\n実装済みを意味しない。keep は現行個性を優先し、P1/P2 は段階的な候補。数を増やす方式は追加しない。具体的な値は同額編成で検証してから決める。\n\n'+'\n'.join(f"- **{r['name']}（{r['id']}） [{r['reviewPriority']}]**：{r['proposalOnly']}" for r in rows if r['boss'])+'\n')
print('saved',len(rows),'characters and',len(bosses),'boss proposals')
