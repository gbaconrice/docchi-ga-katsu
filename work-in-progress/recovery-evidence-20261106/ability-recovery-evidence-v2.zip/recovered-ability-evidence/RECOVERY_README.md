# Ability evidence recovered from worker conversation

Recovered 2026-11-06 by the independent ability-review/test worker. No publication or GitHub changes. These are conversation reconstructions, not a recovered binary or hash-verified copy of the lost final HTML.

## Files

- `ability-integration-cross.recovered.cjs`: complete seven-test program reconstructed from the worker's original creation and subsequent patches. Only recovery provenance comments were added. Requires `reflect-cascade.cjs` beside it and candidate HTML at `../index.html` or argv[2]. Copy into candidate/tests under the original name to run.
- `revival-original-apply.recovered.py`: reconstructed original revival prototype applicator from the tool output in the conversation. This is the OLD prototype, not the final integrated HTML. It retains anchor assertions. Integrator must add log catalog support separately.
- `integration-snippets.recovered.js`: concrete integration fragments and contracts, with provenance labels distinguishing observed code from proposed reconstruction.

## Historical runs, not current verification

The worker actually ran `node tests/ability-integration-cross.cjs` in `ability-integration-20261106/candidate` before loss. Final console output was:

    PASS boot 5 scripts
    PASS solo start
    PASS boss attack and exposure multiply exactly once
    PASS exposed victim still receives exactly 30 death-burst damage
    PASS revived summoner spends only remaining charges with unique physical child tokens
    PASS three burst waves log each defeated physical unit exactly once
    PASS exposure duration and immunity each emit one expiry observation
    PASS canonical revival log preserves child identity through replay and fresh transfer receivers
    PASS canonical frameFor captures revival channel, completion and cancellation poses tick for tick
    LIMITATION: Node pose/transport checks do not validate actual browser rendering or real-network reconnects.
    SUMMARY 7 passed, 0 failed

These historical results DO NOT establish that the recovered 119-test HTML or a new integration passes. No actual-browser, real-device or real-network claim was made. Current recovery validation only checks the reconstructed test's JavaScript syntax; the complete integration needs fresh tests.

## Known exact conflicts against semantic baseline

Original reference was `ui-semantic-integration-20261105/candidate/index.html` containing Claude 346ec2d changes. Revival/summoner literal edit anchors matched. Death-explosion apply line 17 failed because baseline line 6982 had a logging-aware forcedDeaths loop, not a bare loop. Preserve that loop and append burst resolution, including new death observations. Status apply line 25 failed because baseline hit line 6535 already multiplies by bossDamageScale; add exposureFactor once without removing the scale.

## Intended mechanics

Revival: candle_archdeacon group heal reduced from 18 x 2 to 12 x 1. Radius90, windup90 ticks, one successful revival per army, original combatant only, HP25% capped60, desert healing factor applies. Exclude summons, revived bodies, support-only/dmg0, splitters, contact suicide bombers. Fresh token ORIGINAL/revive:1 with ownerToken ORIGINAL; original remains dead. Preserve finite resources; reset transient effects/actions. Commit only after death burst chains and summon capacity reservations, before winner. Active cap64/team, history256/team and512 total, time limit60s, bounded placement25 probes.

Death burst: only shellburst_arcade; damage30, radius36 including target body edge, cap4 nearest ground enemies, stable tie order, no friendly fire, initial body only, once. Same-tick simultaneous waves, no recursion. One-hit ward applies; reflection/lifesteal/followup/contact counters do not. shellburst_arcade is NOT in baseline BOSS_KINDS, so global boss scaling does not alter current30. Exposed targets still take30. Resolve chains before split/revival/winner. Do not change existing bombbug contact explosion.

Summoner: wraith summonCharges4, summonCooldown1; initial delay.25 unchanged, stats and goblin stats unchanged. COST.wraith9 and frozen growth catalog wraith cost9/estimateCost9. Preserve all other catalog data. Revived wraith has only remaining charges, same spawnCount, unique new physical parent token. Existing MVP excludes summon damage; revive remap only direct attacks by revived original combatant.

Exposure: glasswing_sting_moth multiplier1.2, duration120 ticks, immunity210 ticks; melee successful hit reserves next-tick effect, no same-tick amplification, no multiplicative stacking/refresh. Amplify only melee/projectile/direct/cone/area/cleave, not poison/terrain/counters/reflection/death_explosion. Rune exorcist cleanses tick-start slow/root and exposure but not poison; immunity survives cleanse. Five exposure fields not inherited on revival. New presentation bit32768, valid range65535, append exposure_cleansed FX without changing old IDs. Expiry observation MUST precede clearing fields.

## Log and presentation contracts

Register six new types: revive_start, revive_complete, revive_cancel, death_explode, exposure_applied, exposure_cleansed. Completion targets the new childToken actor and stores old targetToken as @original. Log actors remain distinct physical identities; do not collapse revived actor into original. Burst chain new deaths receive one unit_defeated observation each.

Earlier speculation that absent reviveDueTick replay serialization implied pose divergence was disproved. createCanonicalRecording captures `frameFor:u=>baseSpriteFrame(u)` in row[7]; multiplayer spriteFrame returns recorded u.pose. Seventh test proved exact numerical frame parity through channel/completion/source-death cancellation. Actual browser pixels remain unverified.

## Source locations from lost semantic baseline

- TYPES ability assignments6098-6104; BOSS_KINDS6094.
- BattleInsights6172+ (summon damage intentionally excluded).
- battleLogEntityToken6387; tick expiry observers6402-6418.
- hit6525+; boss scaling6535; root/healblock/lifesteal6550-6553.
- normal HP commit6969, forcedDeaths6982, healing-block cleanup6983.
- log catalog9431+, actor catalog9438+, record capture9460+.

Line numbers are historical, not valid offsets for any newly recovered candidate.
