/* EVIDENCE FRAGMENTS, not a standalone application.
 * Recovered from worker tool outputs/conversation 2026-11-06.
 * Do not run wholesale. Parent must adapt anchors and rerun all tests.
 */

// OBSERVED prototype opt-ins, inserted after TYPES.tetherlash_adept.pullDistance=12;
Object.assign(TYPES.candle_archdeacon,{groupHealAmount:12,groupHealCap:1,reviveRadius:90,reviveWindupTicks:90,reviveHpRatio:.25,reviveHpCap:60});
Object.assign(TYPES.shellburst_arcade,{deathExplosionDamage:30,deathExplosionRadius:36,deathExplosionTargetCap:4});
Object.assign(TYPES.wraith,{summonCharges:4,summonCooldown:1});
Object.assign(TYPES.glasswing_sting_moth,{exposureMultiplier:1.2,exposureTicks:120,exposureLockTicks:210});

// OBSERVED semantic baseline loop. Preserve this instead of original bare-loop anchor.
for(const u of forcedDeaths){const logWasDead=!!u.dead;u.hp=0;u.dead=true;if(!logWasDead)observeBattleLogExtra({type:'unit_defeated',targetToken:battleLogEntityToken(u),tick:contactTick,reason:'self-destruct'});}

// OBSERVED original death-explosion prototype block. Append after forcedDeaths,
// before healing-block cleanup, splitting, revival and winner checks.
let deathBurstWave=alive.filter(u=>u.dead&&TYPES[u.k].deathExplosionDamage&&!u.deathExplosionSpent&&!u.ownerToken&&!u.summoned&&!u.revived);
while(deathBurstWave.length){
 pending.clear();insightDamageEvents.clear();
 const survivors=alive.filter(u=>!u.dead),nextWave=[];
 for(const source of deathBurstWave){
  source.deathExplosionSpent=true;const t=TYPES[source.k];
  const targets=survivors.filter(v=>v.side!==source.side&&targetLayers.get(v)==='ground'&&Math.hypot(v.x-source.x,v.y-source.y)<=t.deathExplosionRadius+radiusOf(v)+1e-7).sort((a,b)=>Math.hypot(a.x-source.x,a.y-source.y)-radiusOf(a)-(Math.hypot(b.x-source.x,b.y-source.y)-radiusOf(b))||stableOrder(a,b)).slice(0,t.deathExplosionTargetCap);
  if(collectEvents)publishCombatEvent({type:'death_explode',sourceToken:tokenOf(source),sourceKind:source.k,tick:contactTick,x:source.x,y:source.y,radius:t.deathExplosionRadius,count:targets.length});
  for(const v of targets)hit(v,t.deathExplosionDamage,false,source.k,tokenOf(source),'death_explosion');
 }
 for(const [u,delta]of pending){
  const before=Math.max(0,u.hp);u.hp+=delta;if(u.hp<=0)u.dead=true;
  // RECONSTRUCTED integration addition (not a verbatim recovered final line).
  // survivors were living at start of this wave, so any dead pending target is new.
  if(u.dead)observeBattleLogExtra({type:'unit_defeated',targetToken:battleLogEntityToken(u),tick:contactTick,reason:'hp'});
  let remaining=Math.max(0,before-Math.max(0,u.hp));const records=insightDamageEvents.get(u)||[];
  if(new Set(records.map(r=>String(r.sourceToken??''))).size>1&&records.reduce((n,r)=>n+r.amount,0)>remaining+1e-9)BattleInsights.markIncomplete();
  for(const record of records){const credited=Math.min(remaining,record.amount);remaining-=credited;if(credited>0)BattleInsights.hit(record.sourceToken,u.side,credited,units);}
  if(u.dead&&TYPES[u.k].deathExplosionDamage&&!u.deathExplosionSpent&&!u.ownerToken&&!u.summoned&&!u.revived)nextWave.push(u);
 }
 deathBurstWave=nextWave.sort(stableOrder);
}

// OBSERVED exposure helpers.
function exposureActive(u,tick){return !u.dead&&(u.exposureStartTick??Infinity)<=tick&&tick<(u.exposureUntilTick??0);}
function clearExposure(u){delete u.exposureStartTick;delete u.exposureUntilTick;delete u.exposureMultiplier;delete u.exposureSourceToken;}

// RECONSTRUCTED tick-start expiry observation and cleanup, consistent with observed
// integrated prefix and historical exactly-once test. Must run before deleting fields.
for(const u of units){
 if(!u.dead&&Number.isSafeInteger(u.exposureUntilTick)&&u.exposureUntilTick<=contactTick)observeBattleLogExtra({type:'status_expired',targetToken:battleLogEntityToken(u),status:'exposure',tick:contactTick,untilTick:u.exposureUntilTick,reason:'expired'});
 if(!u.dead&&Number.isSafeInteger(u.exposureImmuneUntilTick)&&u.exposureImmuneUntilTick<=contactTick)observeBattleLogExtra({type:'status_expired',targetToken:battleLogEntityToken(u),status:'exposureImmunity',tick:contactTick,untilTick:u.exposureImmuneUntilTick,reason:'expired'});
 if(u.dead||(u.exposureUntilTick??Infinity)<=contactTick)clearExposure(u);
 if(u.dead||(u.exposureImmuneUntilTick??Infinity)<=contactTick)delete u.exposureImmuneUntilTick;
}

// OBSERVED prototype snapshot, after slowSnapshot declaration.
const exposureSnapshot=new Map(alive.filter(v=>exposureActive(v,contactTick)).map(v=>[v,{until:v.exposureUntilTick,multiplier:v.exposureMultiplier,sourceToken:v.exposureSourceToken}])),exposureIntents=new Map();

// RECONSTRUCTED merged hit amount, preserving observed baseline bossDamageScale.
// Compute this after guard interception so the actual target's exposure is used.
const exposure=exposureSnapshot.get(u),exposureFactor=exposure&&['melee','projectile','direct','cone','area','cleave'].includes(delivery)?exposure.multiplier:1;
let amount=n*exposureFactor*(TYPES[sourceKind]?.bossDamageScale||1)*(followup?TYPES[sourceKind].followupMultiplier:1)*(ranged?(TYPES[u.k].armor||1):1);

// OBSERVED prototype hit-side status reservation, before healingBlockTicks branch.
if(amount>0&&remainingHpBeforeHit>0&&delivery==='melee'&&TYPES[sourceKind]?.exposureTicks&&(u.exposureImmuneUntilTick??0)<=contactTick){const attacker=alive.find(v=>tokenOf(v)===sourceToken);if(attacker&&attacker.side!==u.side){const t=TYPES[sourceKind],old=exposureIntents.get(u),candidate={source:attacker,multiplier:t.exposureMultiplier,ticks:t.exposureTicks,lockTicks:t.exposureLockTicks};if(!old||candidate.multiplier>old.multiplier||candidate.multiplier===old.multiplier&&(candidate.ticks>old.ticks||candidate.ticks===old.ticks&&stableOrder(attacker,old.source)<0))exposureIntents.set(u,candidate);}}

// OBSERVED prototype replacement of cleanse commit, then new exposure commit.
// Also adapt target selection to (slowSnapshot.has(v)||exposureSnapshot.has(v))
// and store exposure:exposureSnapshot.get(target) with each cleanse intent.
for(const a of cleanseIntents){if(a.target.dead)continue;if(a.previousUntil!==undefined){a.target.slowUntil=elapsed;a.target.slowFactor=1;if(collectEvents)publishCombatEvent({type:'slow_cleansed',sourceToken:tokenOf(a.source),targetToken:tokenOf(a.target),x:a.target.x,y:a.target.y,previousUntil:a.previousUntil,tick:contactTick});}if(a.exposure&&a.target.exposureUntilTick===a.exposure.until&&a.target.exposureSourceToken===a.exposure.sourceToken){clearExposure(a.target);if(collectEvents)publishCombatEvent({type:'exposure_cleansed',sourceToken:tokenOf(a.source),targetToken:tokenOf(a.target),x:a.target.x,y:a.target.y,tick:contactTick});}a.source.cleanseCd=TYPES[a.source.k].cleanseCooldown;}
for(const [u,a]of [...exposureIntents].sort((a,b)=>stableOrder(a[0],b[0]))){if(u.dead||u.hp<=0||(u.exposureImmuneUntilTick??0)>contactTick)continue;u.exposureStartTick=contactTick+1;u.exposureUntilTick=contactTick+1+a.ticks;u.exposureImmuneUntilTick=contactTick+1+a.lockTicks;u.exposureMultiplier=a.multiplier;u.exposureSourceToken=tokenOf(a.source);if(collectEvents)publishCombatEvent({type:'exposure_applied',sourceToken:tokenOf(a.source),targetToken:tokenOf(u),tick:contactTick,startTick:u.exposureStartTick,untilTick:u.exposureUntilTick,multiplier:a.multiplier,x:u.x,y:u.y});}
for(const u of units)if(u.dead){clearExposure(u);delete u.exposureImmuneUntilTick;}

// OBSERVED integrated catalog, read directly before original focused test passed.
Object.assign(BATTLE_LOG_CATALOG,{
 "revive_start":{"s":["sourceToken"],"t":["targetToken"],"text":"{source}が{target}の復活詠唱を開始","extra":{}},
 "revive_complete":{"s":["sourceToken"],"t":["childToken"],"text":"{source} → {target}：HP{actualAmount}で復活","extra":{"original":"targetToken"}},
 "revive_cancel":{"s":["sourceToken"],"t":[],"text":"{source}の復活詠唱が中断：{reason}","extra":{}},
 "death_explode":{"s":["sourceToken"],"t":[],"text":"{source}が死亡時爆発：地上の敵{count}体が範囲内","extra":{}},
 "exposure_applied":{"s":["sourceToken"],"t":["targetToken"],"text":"{source} → {target}：弱点露出（受ける通常攻撃{multiplier}倍）","extra":{}},
 "exposure_cleansed":{"s":["sourceToken"],"t":["targetToken"],"text":"{source}が{target}の弱点露出を解除","extra":{}}
});
// INTEGRATION REQUIREMENT: completion prototype emitted hp, catalog reads actualAmount.
// Emit actualAmount:child.hp (possibly alongside hp) or map hp at log normalization.
// Add semantic tones and Japanese labels exposure/exposureImmunity; reason labels
// source-dead, battle-ended, ineligible, no-space need appropriate displayed text.

// OBSERVED prototype indicator.
function drawExposureIndicator(u){
 if(u.dead||!((u.presentationFlags||0)&32768)||((u.presentationFlags||0)&2))return;
 const x=Math.max(10,Math.min(FIELD.w-10,u.x)),y=Math.max(10,u.y-28);
 ctx.save();ctx.globalAlpha=1;ctx.fillStyle='#2c1828';ctx.fillRect(x-9,y-8,18,16);ctx.strokeStyle='#ffd27f';ctx.lineWidth=1.5;ctx.strokeRect(x-9,y-8,18,16);ctx.fillStyle='#fff2cf';ctx.font='bold 11px sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('弱',x,y);ctx.restore();
}
// Insert drawExposureIndicator(u) beside drawRootIndicator(u);drawGuardIndicator(u).
// Extend validFlags max32767 to65535; OR the next bit into fourSpeciesPresentationFlags:
// (!u.dead&&(u.exposureStartTick??Infinity)<=Math.round(elapsed*60)&&Math.round(elapsed*60)<(u.exposureUntilTick??0)?32768:0)
// Append exposure_cleansed to FX_KINDS, EFFECT_META {frames:1,fps:2}, cap6.
// For event exposure_cleansed admitEffect('exposure_cleansed',event.x,event.y-28,face).
// Draw its box via fillRect(x-9,y-8,18,16), strokeRect same, colors #193b3c/#b7fff1/#effffb,
// font bold11px sans-serif, center/middle, fillText('解',x,y).
// Map death_explode to existing bomb_explode audio and bomb_explosion visual.
