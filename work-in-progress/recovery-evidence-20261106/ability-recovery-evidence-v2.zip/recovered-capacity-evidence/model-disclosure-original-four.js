// Insert after the ability opt-ins and before starting a round.
// This corrects provenance only. The old score remains a nominal reference, not a calibrated prediction.
(()=>{
 const affectedIds=new Set(['candle_archdeacon','glasswing_sting_moth','shellburst_arcade','wraith']);
 const priorMetadata=compositionEstimator.metadataFor.bind(compositionEstimator);
 compositionEstimator.metadataFor=pair=>{
  const old=priorMetadata(pair),changed=[...new Set(pair.flatMap(army=>Object.keys(army)).filter(k=>affectedIds.has(k)))].sort();
  if(!changed.length)return old;
  return {...old,predictionStatus:'NOMINAL_ONLY_CHANGED_ABILITIES',calibratedStatus:'not calibrated after ability changes',calibrated:false,confidenceClaim:false,scoreInterval:[-1,1],untrainedTypeIds:[...new Set([...(old.untrainedTypeIds||[]),...changed])].sort(),changedAbilityTypeIds:changed,note:'The predecessor score does not include the changed abilities. It is a nominal reference only, not a calibrated win prediction.'};
 };
})();
