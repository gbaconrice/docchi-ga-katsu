from pathlib import Path
import json,hashlib
source=Path('ability-integration-20261106/candidate/index.html');s=source.read_text()
needle='const growthGenerator=TypedGrowthGenerator.createTypedGenerator(';a=s.index(needle)+len(needle);catalog,end=json.JSONDecoder().raw_decode(s[a:]);end+=a
for k,v in {'wraith':5,'bone_crown_lich':7,'slime':2}.items():catalog[k]['deploymentUnits']=v
s=s[:a]+json.dumps(catalog,ensure_ascii=False)+s[end:]
a='let headcountCap=64;function fit(kinds){if(!Array.isArray(kinds)||kinds.length>Math.min(64,headcountCap)||kinds.some(k=>!catalog[k])||kinds.filter(k=>catalog[k].boss===true).length>1)return null;'
b='''let headcountCap=64,carriedRosterSignature=null;
 const deploymentCount=kinds=>kinds.reduce((n,k)=>n+(catalog[k].deploymentUnits||1),0);
 // Reserve space for finite summons/splits before choosing an army. Existing winners stay intact.
 function fit(kinds){if(!Array.isArray(kinds)||kinds.length>Math.min(64,headcountCap)||kinds.some(k=>!catalog[k])||kinds.filter(k=>catalog[k].boss===true).length>1)return null;if(deploymentCount(kinds)>32&&signature(kinds)!==carriedRosterSignature)return null;'''
assert s.count(a)==1;s=s.replace(a,b)
a="if(![null,'A','B','draw','invalid'].includes(previousOutcome))throw Error('INVALID_PREVIOUS_OUTCOME');";assert s.count(a)==1;s=s.replace(a,a+"carriedRosterSignature=carryKinds.length?signature(carryKinds):null;")
s=s.replace('return Object.freeze({generate,fit,estimateCost:cost,catalog,headcountCapFor});','return Object.freeze({generate,fit,estimateCost:cost,catalog,headcountCapFor,deploymentCount});').replace('return Object.freeze({generate,fit:normal.fit,estimateCost:normal.estimateCost,catalog:normal.catalog});','return Object.freeze({generate,fit:normal.fit,estimateCost:normal.estimateCost,catalog:normal.catalog,deploymentCount:normal.deploymentCount});')
out=Path('ability-balance-independent-20261106/capacity-candidate');out.mkdir(exist_ok=True);(out/'index.html').write_text(s)
print(hashlib.sha256(s.encode()).hexdigest())
