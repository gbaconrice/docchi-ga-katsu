# Recovery status

These files were recovered from this worker's surviving conversation transcript, not from surviving disk originals. No publication was performed. Files are created exclusively; existing recovery files are not overwritten.

## Complete code retained

- build-capacity-candidate.py: complete source from the original tool output. Requires the missing pinned ability integration input. Do not run against the older 119-test artifact as if it were the correct source.
- model-disclosure-original-four.js: complete original four-type draft, NOT the final disclosure. It omits rune_exorcist and all 46 retuned bosses.
- capacity-disclosure.cjs: complete test code reconstructed verbatim from its creation command. Requires the missing fixture and the repository's reflect-cascade.cjs VM harness.
- regenerate-fixture.cjs: retained fixture-generation command; source paths and inputs are missing. The fixture cannot be recovered merely by running against an older game.

## Missing exact artifacts

- Final integrated index.html and its final hash were not retained in this worker context.
- Fixture JSON containing 300 score/metadata rows and 72 matchup choices was not printed, so its exact values are missing.
- generation-original.json, the input source for the 72 matchup arguments, is also missing from this worker context.
- Full final disclosure wrapper was not printed. The exact final metadata propagation function and return statement were printed and are preserved in final-disclosure-observed-fragments.txt; a full reconstructed wrapper is explicitly labelled reconstruction.

## Verified historical provenance

Original ability integration index SHA256: 7be68eaef4d094584d5990f203dd0b0b3c5f249de12aa49195525f3f3c4db90e
Capacity-only index SHA256: bc36194e19c8b89e72e78c74714d960231150b81316149f3e0f1dfd6c7805701
Rejected price-only experimental candidate SHA256: cf57e08560f025858ec1d3d9817e052f1ebbd2d982d80d091a2d25fe6bdf11d4 (must not be used)

The recovered test previously ran successfully against the lost final candidate: seven test groups PASS, full TYPES/COST/combat/predict/vector hashes unchanged, all 300 original scores unchanged, 5 changed abilities + 46 bosses disclosed, 72 mixed round/outcome cases and 72 pinned capacity-only choices/margins unchanged. This is historical execution evidence, not a fresh pass on a recovered candidate. Browser layout, mobile FPS and statistical calibration were not established.

The parent explicitly planned final metadata coverage for candle_archdeacon, glasswing_sting_moth, shellburst_arcade, wraith, rune_exorcist and BOSS_KINDS (46), preserving estimator predict/features verbatim. No odds/UI layout change was intended.
