// RECONSTRUCTION, NOT recovered verbatim source or verified final artifact.
// Reconstructs the documented/tested policy using the exact observed final return.
// Insert after ability and boss opt-ins, before starting any round.
(()=>{
 const affectedIds=new Set(['candle_archdeacon','glasswing_sting_moth','shellburst_arcade','wraith','rune_exorcist']);
 const bossIds=new Set(BOSS_KINDS);
 const priorMetadata=compositionEstimator.metadataFor.bind(compositionEstimator);
 compositionEstimator.metadataFor=pair=>{
  const old=priorMetadata(pair),ids=[...new Set(pair.flatMap(army=>Object.keys(army)))],changed=ids.filter(k=>affectedIds.has(k)).sort(),bosses=ids.filter(k=>bossIds.has(k)).sort();
  if(!changed.length&&!bosses.length)return old;
  return {...old,predictionStatus:changed.length?'NOMINAL_ONLY_CHANGED_ABILITIES':'NOMINAL_ONLY_RETUNED_BOSSES',calibratedStatus:'not recalibrated after ability or boss changes',calibrated:false,confidenceClaim:false,scoreInterval:[-1,1],untrainedTypeIds:[...new Set([...(old.untrainedTypeIds||[]),...changed,...bosses])].sort(),changedAbilityTypeIds:changed,retunedBossTypeIds:bosses,note:'能力・大型の変更後は未校正です。旧モデルの選定スコアを参考値として使っており、現在の勝率を示すものではありません。'};
 };
})();
