# Recovery findings from the integration conversation

This file records prior work retained in conversation, not a newly recovered copy of the final source or a new test result. The original `ability-final-integration-20261106` directory and local ZIP files are absent after the environment restart. A new implementation must receive a new hash and rerun all tests; do not label it the original final candidate unless its bytes independently match.

## Exact historical identities

- Current main base: `029846150bef21e703025f795895b58300b3bb89`; index SHA256 `2a7a05a56dee92858bcb7ffa69e06f6f5dd05528d79ae5c7dde32678982df929`.
- Claude boss branch: `346ec2d43bf6fbf705cc47ced997e104265d2ba4`; all 46 boss changes were preserved. Separate independent 36-unit rebalance was NOT adopted.
- Recoverable 119-test UI base: `040ff2037e7ba6760a22b174b0d742224e45fc242cbce8731c3a98f8473b1d95`.
- Semantic UI candidate, 122 tests: `7d48346cb2a96e45430319a25ee87956995f8be83cf5709212de33bd1d66b3e0`.
- Four-ability candidate, 129 tests: `7be68eaef4d094584d5990f203dd0b0b3c5f249de12aa49195525f3f3c4db90e`; content revision `12c0b67d5626a63dac660ca7b66d5a1f2fb6a318acfa5338d4667221dbd0c8c7`.
- Capacity-only experimental candidate: `bc36194e19c8b89e72e78c74714d960231150b81316149f3e0f1dfd6c7805701`.
- Final capacity/disclosure candidate, 130 tests: `210708a26ca86f70af4909c1fffe9dff82c740909e74d2b568454338a8e3c3fd`; content revision `0fd43d2534d39a9b53571dff65ab6df98b611e10eca4d9ff828bd868c91743d2`.
- REJECTED price-only experimental candidate: `cf57e08560f025858ec1d3d9817e052f1ebbd2d982d80d091a2d25fe6bdf11d4`. Do not restore or reintroduce price-only opponent scoring.

## Concrete intended changes after the 119-test base

### Semantic text and event tones

Use action-specific tones for battle summary/history and make air-priority descriptions explicit for the two affected characters. Legacy `haste_changed` means attack speed, not movement speed, so its action text uses attack tone. Preserve event records, combat, odds and other UI geometry. The exact names/text for the two characters must be recovered from source history or a worker; this note does not invent them.

### Four abilities

1. `candle_archdeacon`: revival, one successful revival per army; 90 px range, 90-tick cast, restored HP = 25% of target maximum, capped at 60. Keep finite resource counters already spent; do not refresh summon, split, shield, or other finite abilities. Old standard healing 18 × 2 becomes 12 × 1. Eligibility was checked across all 300 units, with 265 eligible and 35 excluded. Exact exclusion rules require recovered tests/code.
2. `shellburst_arcade`: death burst, 30 damage, radius 36, up to 4 enemies, ground targets, one activation on the unit's initial life. Revived units must not earn another burst. Preserve lethal-hit and defeat accounting. Explicit defeat-log handling was added for this pathway.
3. `wraith`: 4 summons instead of 3; summon cooldown 1; cost 9 instead of 8. Other costs/Claude values unchanged.
4. `glasswing_sting_moth`: exposure marks an enemy for ×1.2 damage, active from the next tick, lasts 120 ticks, 210-tick lock; `rune_exorcist` cleanse includes exposure. Preserve replay determinism and activation ordering. Explicit expiry logging was added.

Six log-event types were added across these features. Their exact names and payload contracts must come from recovered tests/code, not guesses in this note.

### Deployment reservation cap

Newly selected armies reserve at most 32 deployed units. Wraith reserves 5 (body + 4 summons), lich 7 (body + 6), slime 2 (body dies before children). Existing winning carry armies remain legal and unchanged via sorted-signature exemption; fresh selection resets exemption. Keep pre-existing headcount, packing and boss rules. Combat safety caps stay 64 per team and 512 total. Do not alter scores/prices/predictor math to enforce this cap.

### Honest model metadata

Keep `predict`, features, learned weights, all TYPES, prices and combat unchanged relative to the ability candidate. Mark changed abilities plus cleanse and 46 retuned bosses as uncalibrated. Identifiers included `NOMINAL_ONLY_CHANGED_ABILITIES`, `NOMINAL_ONLY_RETUNED_BOSSES`, `changedAbilityTypeIds`, `retunedBossTypeIds`, `calibratedStatus`, and `note`; propagate into `modelDecision`. This was metadata only, not a new actual UI odds screen or layout. Explain in Japanese that the legacy score is nominal and is not calibrated current winning probability; [-1,1] is a score domain, not a confidence interval.

Known unresolved model mismatches: wraith feature cost 8/summons 3 vs actual 9/4; candle heal feature 36 vs actual 12 plus revival; death burst and exposure absent; basalt feature HP420 vs actual HP2100. Shellburst4 versus goblin12 nominal margin stayed `-0.6074706005326166`.

## Prior validation, not a claim about newly reconstructed files

- Final candidate had 130 passing regression scripts.
- Independent capacity test had 7 groups, exact unchanged 300 scores, 72 edge cases and 72 pinned capacity-only rosters/margins.
- 160 generation cases: maximum new reservation32, zero over-cap, zero errors, zero carry loss; prior variant max89,11 over-cap cases.
- 72 complete battles (same army inputs by ID, not list order) were exactly unchanged: 32 A wins,37 B wins,3 draws, mean19.2336 seconds; one pre-existing60-second draw stayed.
- Dense generated encounter round20/streak3/carry32archer/seed31692 changed opponent16wraith to16rider, max active32:64 to32:16, history109 to48, duration13.27 to19.27sec, both B win.
- Prior ability measurement showed shellburst4 versus goblin12 changed7/8 outcomes. Dense wraith stress became more expensive before the deployment cap. VM timing is not device FPS.
- Actual browser, iOS, GRAVITY network, and FPS were not verified at that historical final stage.

## Historical package hashes (files currently missing)

- `abilities-review.zip`:32617940 bytes, SHA256 `2b638c034e73be29a7a7ff70ab015638f1895ee76151dbbac8c741bc598e8c74`.
- `abilities-update.zip`:270419 bytes, SHA256 `2ab6df8cc98c62c00de2ac878be1ec0ae9996daee6e5a916e1fc18d63f5adf95`.
- `capacity-disclosure-update.zip`:241720 bytes, SHA256 `ad1540d8604912a0e9176e35c26c0b2a45a891af3db0917a54dfa4ae2223f3ab`.
- `capacity-disclosure-update.patch`:2340895 bytes, SHA256 `2cb4f742da79cf0a895505732938e3733a02e12b2f4fca8b717eb5c50066157d`.
- `final-capacity-review.zip`:32732305 bytes, SHA256 `dad2ba1f1702a250fefae8374e47e20bc5c3c04168aa4b17807c3af063da2d67`.
- `main-recovery.zip`:4337991 bytes, SHA256 `c7a6a872fd5df7683b0a54cf90bac31226199b82a181b74af7599cb8ab3dbe27`.

The last package reconstructed the latest index from fixed main with 198 line-edit operations and536 other files. All segment/input/result checks and focused tests passed at the time. Its23 chunk checksums are the only portion successfully retrievable remotely, in GitHub blob `b02a8af7b29e78fb4ac998dafe35baef4c36cce2`. Source chunks were denied before upload. Hashes alone cannot reconstruct content.

## Publication precautions from completed review

Candidate packaging omitted589 tracked main files (old previews/releases), so never replace the entire repo or use deleting sync. Overlay only verified paths; preserve old releases, Claude source and unrelated files. `tools/build-gravity-single.cjs` must support the fifth home-animation script. Publishing root index does not update a separate GRAVITY release automatically. Keep CURRENT_PREVIEW_MANIFEST and release status truthful; candidate's old manifest says unpublished.

DoubleUpLedger/MultiWallet, SoloWallet and ScoreBridge were byte-identical to main/Claude. No browser persistent storage API or destructive migration was added. Progress is pre-existing memory-only data, so page refresh can lose a run. New content revision deliberately rejects mixed-version multiplayer. Preserve prior commit and use normal revert, not force-reset, for rollback.
