# Emergency measurement recovery

## Provenance and status

Recovered from this worker's pre-reset conversation, not from the vanished files. No game execution has been performed during recovery. Only `node --check` syntax checks have run successfully on the four .cjs files. **This is not a rerun PASS.**

- `harness.cjs`: original complete harness body survived verbatim tool output; transcribed, with recovery comment. No original file hash available.
- `runner.cjs`: NEW standalone reconstruction from complete original simulate.cjs output and previously authored measure.cjs commands. Same experiment setup; local dependencies, bounded terrain discovery, explicit field validation, SHA captured at startup and failing invariant exit status added. Do not call this byte-identical recovery.
- `target-jobs.json`, `density-jobs.json`: exact prior fixture generation reconstructed from conversation.
- `check-mechanics.cjs`, `check-results.cjs`: NEW executable checks based on printed historical values/specification, not recovered original regression tests.
- `recovered-hooks.txt`: verbatim surviving source fragments only. Missing braces/context explicitly make it unsuitable as a patch.
- Historical observations below are manually recovered summaries. Original raw per-fight JSON is lost. These are NOT new measurements.

## Run against a reimplemented candidate

Set GAME_HTML to its index.html. Use an output filename that does not already exist.

1. `GAME_HTML=... node check-mechanics.cjs`
2. `GAME_HTML=... node runner.cjs NEW-targets.json target-jobs.json`
3. `node check-results.cjs NEW-targets.json --abilities`
4. `GAME_HTML=... node runner.cjs NEW-sessions.json`
5. `node check-results.cjs NEW-sessions.json`
6. `GAME_HTML=... node runner.cjs NEW-density.json density-jobs.json`

Run from this directory, or give absolute script/fixture paths. For true matched-army comparison run the base sessions first, then pass their JSON as runner's third argument on the candidate. These are direct generator/combat VM simulations, not UI play. Instrumented VM time is not FPS. The checker covers x/y/hp/cd every tick; it does not claim every optional numeric field is finite.

## Revival specification, known versus missing

The revivalEligible helper BODY was never printed in this conversation and cannot be recovered exactly. Do not invent its exact predicates.

The prior UI text explicitly described: once per army per fight; nearby initial unit; 90-tick cast; 25% HP capped at 60; summoned, support-only, self-exploding and splitting units excluded. This supports a test matrix but does not establish exact property names or every exclusion. The revived-life constructor and collision-free placement helper bodies are also missing.

Exact surviving resolution conditions: source alive; corpse exists and still passes revivalEligible; no same-side unit with reviveUsed; distance <=90+epsilon; living plus pending occupancy below TEAM_CAP; hasCreatedRoom(side); elapsed before60; revivalPosition succeeds. Completion sets reviveClaimed on corpse, reviveUsed on caster, adds a new life object, increments createdCounts, emits revive_complete. Failure emits source-dead/ineligible/no-space. Retry delay 30 ticks. HP formula applies fieldHeal after min(baseHP*.25,60), with minimum1. Source cooldown resets to type rate. Claimed corpse is hidden in drawing. Revived life is excluded from child-priority targeting via revivalRootToken.

Required reimplementation tests beyond the provided bulk runner: eligible initial normal corpse; initial support-only corpse; summoned child; self-exploder; splitter; already claimed/revived life; two casters same army; source death mid-cast; target invalidation; out of range; 64 living+pending cap; creation-history cap; no safe spawn location; battle end during cast; timeout boundary; original token lineage; render hiding; child-priority exclusion. These are test specifications, NOT previously recovered passing tests.

## Other mechanics checks

- Death burst 30 damage, radius36, max4 ground targets; one-shot deathExplosionSpent; owner/summoned/revived excluded; simultaneous waves resolve before split/revival/winner checks. Exact damage accumulation implementation missing.
- Moth exposure 1.2 multiplier, 120 duration ticks, 210 lock ticks; applies starting next tick. Cleansing removes active exposure but clearExposure does not remove immunity. Dead units remove both. Rune has radius100/cooldown1.5. Test same-tick order, no stacking, lockout, cleanse then attempted reapplication, death cleanup. Exact damage-path classification was not printed, so ordinary-attack-only interpretation needs dedicated checks.
- Wraith4 children, initial0.25s/cooldown1s, growth cost9. Base had3/cost8.
- Basalt type values are asserted in check-mechanics, including hp2100/damage42/boss scale3/armor.5. This worker did not independently recover a full boss-counter matrix.

## Historical results, NOT rerun

Base SHA 7d48346cb2a96e45430319a25ee87956995f8be83cf5709212de33bd1d66b3e0. Integrated SHA 7be68eaef4d094584d5990f203dd0b0b3c5f249de12aa49195525f3f3c4db90e.

80 sessions/build (four terrains, seeds4242/987654321, ten rounds) yielded40 A/40 B each, no carry loss, no core nonfinite, no cap/time violations. Eight generated army pairs changed, zero winner changes. Exact-base-army candidate replay80 yielded zero winner changes/four duration changes. Base sessions had wraith in4 fights; candidate had none. Both lacked other affected units and basalt, so not calibration of those abilities.

64 fixed-roster targeted fights/build triggered candidate totals: revive_start8, revive_complete8, death_explode106, exposure_applied136, exposure_cleansed36, summon_spawn320. Shellburst4 vs goblin12 changed seven of eight winners: base8 losses; candidate6 wins,1 loss,1 mutual-elimination draw. This was cost12 vs24, not equal-budget. Other targeted winner groups unchanged. Maximum targeted duration48.67s, candidate living/team30/history36.

Target budgets L:R (base→candidate): revival20:24 unchanged; shellburst12:24 unchanged; moth/rune15:22 unchanged; wraith32:32→36:32; boss/wraith32:48→32:54; boss/moth32:22 unchanged; boss/shell32:30 unchanged; boss/revival32:48 unchanged.

Density16 wraith/team seed4242 grassland: living peaks61→64/team, history127→158, summons95→126, pending32 both. A wins23.32→22.68 simulated seconds. Sequential instrumented VM11087ms/1399ticks→16752ms/1361ticks, 7.925→12.309ms/tick (1.55x). Single-run diagnostics, not FPS or statistical calibration.
