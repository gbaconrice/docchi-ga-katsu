// NEW reconstruction from the prior simulate.cjs and measure.cjs transcript.
// Standalone local dependency replaces vanished rebalance-large-20261105 path.
const fs=require('fs'),crypto=require('crypto'),{ev}=require('./harness.cjs')();
if(!process.env.GAME_HTML)throw Error('GAME_HTML must identify the build under test');
const sha=crypto.createHash('sha256').update(fs.readFileSync(process.env.GAME_HTML)).digest('hex');
ev(`globalThis.envById={};for(let n=0;Object.keys(envById).length<8&&n<10000;n++){const e=BattleFields.selectRunEnvironment(n);envById[e.fieldId]??=e;}
globalThis.simulateJob=function(job){
const left=job.left,right=job.right,lp=growthGenerator.fit(left),rp=growthGenerator.fit(right);if(!lp||!rp)throw Error('fit failed: '+job.id);
let plan={round:10,seed:job.seed,leftPositions:lp,rightPositions:rp.map(p=>({...p,x:480-p.x}))};
units=OpeningUnits.instantiateOpening(plan,TYPES);if(job.mirror)for(const u of units){u.side=1-u.side;u.x=480-u.x;u.originForward=-u.originForward;}
initialUnits=JSON.parse(JSON.stringify(units));initialKinds=[units.filter(u=>u.side===0).map(u=>u.k),units.filter(u=>u.side===1).map(u=>u.k)];BattleInsights.start(initialUnits);elapsed=0;shots=[];pendingSummons=[];combatEvents=[];state='fight';winner=null;choice=0;battleEnvironment=envById[job.field||'grassland'];
if(!battleEnvironment)throw Error('Unknown field '+job.field);
let ticks=0;const events={},invalid=[],maxAlive=[0,0];let maxTotal=units.length,maxPending=0;
while(state==='fight'&&ticks<3601){combatEvents=[];combatStep(1/60);for(const e of combatEvents)events[e.type]=(events[e.type]||0)+1;ticks++;
maxTotal=Math.max(maxTotal,units.length);maxPending=Math.max(maxPending,pendingSummons.length);
for(let side=0;side<2;side++)maxAlive[side]=Math.max(maxAlive[side],units.filter(u=>!u.dead&&u.side===side).length);
for(const u of units)for(const key of ['x','y','hp','cd'])if(typeof u[key]!=='number'||!Number.isFinite(u[key]))if(invalid.length<5)invalid.push({tick:ticks,kind:u.k,key,value:String(u[key])});}
return {invalid,maxAlive,maxTotal,maxPending,ticks,ended:state!=='fight',id:job.id,left,right,field:job.field||'grassland',seed:job.seed,mirror:!!job.mirror,winner:winner===null?'draw':winner===(job.mirror?1:0)?'A':'B',seconds:Math.round(elapsed*100)/100,remaining:[0,1].map(side=>units.filter(u=>!u.dead&&u.side===(job.mirror?1-side:side)).reduce((s,u)=>s+u.hp,0)),living:[0,1].map(side=>units.filter(u=>!u.dead&&u.side===(job.mirror?1-side:side)).length),events};
};`);
const results=[];
function checkpoint(){fs.writeFileSync(process.argv[2],JSON.stringify({provenance:'NEW EXECUTION using reconstructed harness; not original pre-reset evidence',html:process.env.GAME_HTML,sha256:sha,results},null,2));}
function sim(job){const start=Date.now();const r=ev(`simulateJob(${JSON.stringify(job)})`);r.vmMs=Date.now()-start;return r;}
if(process.argv[3]){
ev(`growthGenerator.generate({round:10,streak:0,carryKinds:['goblin'],seed:4242,previousOutcome:'A',avoidRight:[]})`);
for(const job of JSON.parse(fs.readFileSync(process.argv[3])).results){results.push(sim(job));checkpoint();}
}else for(const field of ['grassland','shallow_ford','crosswind_ridge','volcano'])for(const seed of [4242,987654321]){
let carry=[],streak=0,previousOutcome=null,avoidRight=[];
for(let round=1;round<=10;round++){
const battleSeed=(Math.imul(seed,round*1031)+round*7919)>>>0,args={round,streak,carryKinds:carry,seed:battleSeed,previousOutcome,avoidRight};
const p=ev(`growthGenerator.generate(${JSON.stringify(args)})`),b=sim({id:field+':'+seed+':'+round,left:p.leftKinds,right:p.rightKinds,seed:battleSeed,field});
results.push({...b,session:field+':'+seed,round,costs:p.estimatedCosts,carryPreserved:!carry.length||JSON.stringify(p.leftKinds)===JSON.stringify(carry),archetype:p.archetypeDecision,large:[p.leftKinds,p.rightKinds].map(ks=>ks.filter(k=>ev('TYPES['+JSON.stringify(k)+'].radius')>=20).length)});checkpoint();
const side=b.winner==='B'?1:0;avoidRight=(side===0?p.rightKinds:p.leftKinds).slice();carry=(side===0?p.leftKinds:p.rightKinds).slice();streak=b.winner==='A'?streak+1:b.winner==='B'?1:streak;previousOutcome=b.winner;
}console.error(field,seed,'done');}
checkpoint();
const failures=results.filter(r=>r.invalid.length||!r.ended||r.seconds>60||Math.max(...r.maxAlive)>64||r.maxTotal>512||r.carryPreserved===false);
if(failures.length){console.error('OBSERVED INVARIANT FAILURES',failures.map(r=>r.id));process.exitCode=1;}
