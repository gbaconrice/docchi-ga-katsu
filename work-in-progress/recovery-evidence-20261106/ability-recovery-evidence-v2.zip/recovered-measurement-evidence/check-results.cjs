// NEW invariant and mechanism-incidence checker. Input must be NEW runner results.
const fs=require('fs'),assert=require('assert');const d=JSON.parse(fs.readFileSync(process.argv[2]));
assert(d.provenance?.startsWith('NEW EXECUTION'),'Do not present recovered historical summaries as rerun evidence');
const events={};for(const r of d.results){assert.equal(r.invalid.length,0,r.id+' nonfinite');assert(r.ended&&r.seconds<=60,r.id+' duration');assert(Math.max(...r.maxAlive)<=64,r.id+' living cap');assert(r.maxTotal<=512,r.id+' history cap');assert(r.carryPreserved!==false,r.id+' carry');for(const[k,v]of Object.entries(r.events))events[k]=(events[k]||0)+v;}
if(process.argv.includes('--abilities'))for(const k of ['revive_start','revive_complete','death_explode','exposure_applied','exposure_cleansed','summon_spawn'])assert(events[k]>0,'No functional incidence for '+k);
console.log(JSON.stringify({newExecution:true,sha256:d.sha256,fights:d.results.length,events},null,2));
