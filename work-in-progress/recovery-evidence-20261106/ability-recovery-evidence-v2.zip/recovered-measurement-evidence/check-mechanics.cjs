// NEW tests derived from exact previously printed TYPES values; not recovered old tests.
const assert=require('assert'),{ev}=require('./harness.cjs')();
const expected={candle_archdeacon:{reviveRadius:90,reviveWindupTicks:90,reviveHpRatio:0.25,reviveHpCap:60},shellburst_arcade:{deathExplosionDamage:30,deathExplosionRadius:36,deathExplosionTargetCap:4},wraith:{summonCharges:4,summonInitialDelay:0.25,summonCooldown:1},glasswing_sting_moth:{exposureMultiplier:1.2,exposureTicks:120,exposureLockTicks:210},rune_exorcist:{cleanseRadius:100,cleanseCooldown:1.5},basalt_titan:{hp:2100,dmg:42,rate:3.5,speed:16,radius:26,reach:20,burstWindupTicks:120,burstRadius:58,burstDamage:42,burstCooldownTicks:210,boss:true,bossDamageScale:3,armor:0.5}};
const failures=[];
for(const [k,fields]of Object.entries(expected))for(const [field,value]of Object.entries(fields))try{assert.deepStrictEqual(ev(`TYPES[${JSON.stringify(k)}]?.[${JSON.stringify(field)}]`),value); }catch(e){failures.push(k+'.'+field+': '+e.message);}
try{assert.equal(ev(`growthGenerator.estimateCost(['wraith'])`),9);}catch(e){failures.push('wraith cost: '+e.message);}
for(const fn of ['revivalEligible','revivalPosition','revivalLife','revivalRootToken','exposureActive','clearExposure'])if(ev(`typeof ${fn}`)!=='function')failures.push('missing function '+fn);
if(failures.length){console.error(failures.join('\n'));process.exitCode=1;}else console.log('NEW EXECUTION: recovered mechanics expectations match current GAME_HTML; functional behavior still requires simulations.');
