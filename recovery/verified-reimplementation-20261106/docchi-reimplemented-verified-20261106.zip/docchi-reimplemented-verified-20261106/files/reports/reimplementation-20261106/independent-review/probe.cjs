const fs=require('fs'),path=require('path');
const game=path.resolve(process.argv[2]);
const harness=fs.readFileSync(path.resolve('game-recovery-20261106/reimplementation-20261106/abilities/tests/reflect-cascade.cjs'),'utf8').split("for(const id of ['#red'")[0].replace("fs.readFileSync('index.html','utf8')",`fs.readFileSync(${JSON.stringify(game)},'utf8')`);
const {context,vm}=new Function('require',harness+'\nreturn {context,vm};')(require);
console.log(JSON.stringify(vm.runInContext(`(()=>{
 const corpse={id:'pillar',token:'pillar',k:'pillar_hammerer',side:0,x:100,y:100,hp:0,dead:true,priority:0,originForward:1,cornerStudyNormalPillarUsed:true};
 const child=revivalLife(corpse,{x:100,y:100},60),target={id:'victim',token:'victim',k:'sword',side:1,x:150,y:100,hp:100,dead:false};
 Object.assign(child,{cornerStudyTarget:'victim',cornerStudySince:1,cd:0,guardReadyAt:0});elapsed=4;
 const body=(token,x,y)=>({id:token,token,k:'sword',side:0,x,y,hp:100,dead:false});
 const alive=[child,body('friend1',105,100),body('friend2',95,100),target];
 const before=cornerStudyReady({...child,cornerStudyNormalPillarUsed:true},target,TYPES[child.k],alive,240);
 const after=cornerStudyReady(child,target,TYPES[child.k],alive,240);
 return {eligible:revivalEligible(corpse,{side:0}),sourceFlag:corpse.cornerStudyNormalPillarUsed,revivedFlag:child.cornerStudyNormalPillarUsed??null,expectedBefore:before,actualAfter:after,type:TYPES[child.k]};
})()`,context),null,2));
