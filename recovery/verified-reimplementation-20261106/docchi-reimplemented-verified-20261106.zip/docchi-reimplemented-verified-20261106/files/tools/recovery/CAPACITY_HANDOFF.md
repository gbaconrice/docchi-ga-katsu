# Capacity and model disclosure reconstruction

This is a new implementation from retained policy/code evidence, not the missing historical final artifact. Do not reuse the old final SHA or old 130-test claim.

## Reusable patch

`apply-capacity-disclosure.py PRE_CAP_HTML OUTPUT_HTML [--capacity-only]`

- Supports the independently reconstructed ability source; no lost-source SHA requirement.
- Fails closed on missing/duplicate anchors and already-patched sources. These failure paths were checked.
- Adds deploymentUnits only for wraith5, bone_crown_lich7, slime2.
- New rosters reserve at most32. Sorted exact carry composition is exempt from this new check only; fresh generation clears exemption. Old headcount, boss and packing checks remain in force.
- Combat live cap64/team and total-created cap512 remain untouched.
- Adds metadata for five changed abilities and46 retuned bosses, and propagates it into modelDecision. Japanese note says the legacy score is not current win probability and [-1,1] is a score domain, not a confidence interval.
- Does not change predictor, features, weights, actual prices, catalog prices, combat, UI odds, HTML/CSS outside scripts, or reintroduce the rejected price-only scoring patch.
- Does not refresh CONTENT_REVISION/manifests. Do that once after final integration.

## Fresh validation workflow

From the final candidate root, with the pre-capacity ability/semantic input saved separately:

1. `python tools/recovery/apply-capacity-disclosure.py PRE_CAP_HTML CAP_ONLY_HTML --capacity-only`
2. `python tools/recovery/apply-capacity-disclosure.py PRE_CAP_HTML index.html`
3. `node tools/recovery/build-capacity-fixture.cjs PRE_CAP_HTML CAP_ONLY_HTML tests/fixtures/capacity-disclosure-reimplemented.json`
4. `REQUIRE_NEW_ABILITIES=1 node tests/capacity-disclosure-reimplemented.cjs`
5. Refresh final revision/manifests, then rerun the full combined suite and targeted suite.

The fixture is explicitly labeled fresh-nonhistorical. It pins mechanics/model/catalog costs and300 scores against the supplied pre-capacity input, and72 generation choices/margins against its capacity-only derivation. Metadata is independently checked, plus160 extra generated cases. No absent historical source or fixture is pretended to have been recovered. The tests have no runtime dependency on another workspace.

## Current verified identity

- Pre-capacity ability snapshot: `63734444dfe49de70e3e67edab3204246b86125a876623a256cad92a8fe85816`.
- Capacity-only derivative: see `reports/capacity-reimplementation/ability-cap-only-apply.json` and fixture provenance.
- Combined ability + capacity/disclosure HTML, before final revision/semantic overlay: `4a64e9ed3ea0197dbf072979b0c98a21f51a3eb87fe30c6211e22d30a2746f8c`.
- Applicator SHA256: `195bb67c8089f074e49cfdbfe5974cdec796d4bd7eac6d6513a12bc60278b15e`.

## Verified results

- Capacity suite:7 groups PASS with REQUIRE_NEW_ABILITIES=1; all actual summon/split reservations verified, wraith4/cost9.
- All300 pre-cap scores unchanged; TYPES/COST/combatStep/step/spawnPosition/model/feature/weights/catalog-price hashes unchanged.
- Five ability IDs and all46 boss IDs disclosed; old tail/geometry fields retained.
- Boundary and carry cases include reordered signature, rejected replacement/add/remove, carry16wraith reservation80, carry32wraith reservation160, reset, old headcount/boss/packing checks.
-72 fresh pinned generation choices/margins unchanged by metadata, deterministic repeated generation.
-160 extra generated cases: maximum new reservation32, zero over-cap,128 carries preserved, no errors.
- Recovered ability integration cross suite on combined capacity HTML:7 PASS.
- New ability boundary suite on combined capacity HTML:36 PASS.

## Remaining checks and limits

The earlier exact119-plus-capacity interim full suite had118 PASS/2 FAIL (only stale current manifest and integrated revision). That is not the final combined full-suite result. The parent must overlay semantic tests/changes if needed, refresh CONTENT_REVISION and manifests, rerun all combined tests, and publish only verified paths. This worker did not edit sibling candidates or GitHub/main.

Actual browser layout, iOS, GRAVITY live networking and device FPS remain unverified by these VM checks. Statistical calibration is intentionally not claimed. Original missing final source, historical fixture and historical packages remain unavailable.

## Files to integrate

- `index.html` (or rerun the applicator on the selected final pre-capacity input).
- `tools/recovery/apply-capacity-disclosure.py`
- `tools/recovery/load-game.cjs`
- `tools/recovery/build-capacity-fixture.cjs`
- `tools/recovery/CAPACITY_HANDOFF.md`
- `tests/capacity-disclosure-reimplemented.cjs`
- `tests/fixtures/capacity-disclosure-reimplemented.json`
- `reports/capacity-reimplementation/` (clearly named interim and ability-integrated reports).
