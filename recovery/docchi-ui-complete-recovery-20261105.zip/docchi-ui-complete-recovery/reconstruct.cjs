const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert');
const base=path.resolve(process.argv[2]||''),out=path.resolve(process.argv[3]||'');
assert(process.argv[2]&&process.argv[3]&&base!==out,'Usage: node reconstruct.cjs BASE_INDEX_HTML NEW_OUTPUT_DIRECTORY');
assert(!fs.existsSync(out),'Output directory must not already exist.');
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const edits=JSON.parse(fs.readFileSync(path.join(__dirname,'index-edits.json'),'utf8')),text=fs.readFileSync(base,'utf8');
assert.equal(sha(text),edits.baseSHA256,'Wrong base. Read exact 374f834 index.html; do not apply to an arbitrary branch.');
const lines=text.match(/[^\n]*\n|[^\n]+$/g)||[];
for(const op of edits.ops.slice().reverse()){
 assert.equal(sha(lines.slice(op.start,op.end).join('')),op.oldSHA256,'Input segment mismatch.');
 lines.splice(op.start,op.end-op.start,op.text);
}
const result=lines.join('');assert.equal(sha(result),edits.candidateSHA256,'Reconstruction hash mismatch.');
fs.mkdirSync(out,{recursive:true});fs.cpSync(path.join(__dirname,'files'),out,{recursive:true});fs.writeFileSync(path.join(out,'index.html'),result);
console.log(JSON.stringify({output:out,indexSHA256:sha(result),published:false},null,2));
