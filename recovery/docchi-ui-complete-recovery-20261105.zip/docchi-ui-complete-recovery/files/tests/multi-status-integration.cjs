const fs=require('fs'),vm=require('vm');const html=fs.readFileSync('index.html','utf8');const scripts=[...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)].map(x=>x[1]);const errors=[],events={};const noop=()=>{};const ctx=new Proxy({measureText:()=>({width:10}),createLinearGradient:()=>({addColorStop:noop}),createRadialGradient:()=>({addColorStop:noop}),getImageData:()=>({data:new Uint8ClampedArray(16)})},{get:(o,k)=>k in o?o[k]:noop,set:(o,k,v)=>(o[k]=v,true)});const nodes=new Map();function elem(id){if(!nodes.has(id)){let n={id,hidden:false,disabled:false,style:{setProperty:noop,removeProperty:noop},dataset:{},classList:{add:noop,remove:noop,toggle:noop,contains:()=>false},setAttribute:noop,removeAttribute:noop,getAttribute:()=>null,addEventListener:noop,removeEventListener:noop,appendChild:noop,remove:noop,focus:noop,getContext:()=>ctx,getBoundingClientRect:()=>({width:480,height:538,left:0,top:0,right:480,bottom:538}),querySelector:()=>null,querySelectorAll:()=>[],getClientRects:()=>[],textContent:'',value:'',width:480,height:538};nodes.set(id,n)}return nodes.get(id)}
const doc={hidden:false,documentElement:elem('html'),body:elem('body'),querySelector:s=>elem(s),querySelectorAll:()=>[],getElementById:id=>elem('#'+id),createElement:t=>elem('new-'+t),addEventListener:(n,f)=>{(events[n]??=[]).push(f)},removeEventListener:noop};const pendingImages=[];class Img{constructor(){pendingImages.push(this);this.complete=false;this.naturalWidth=0;this.naturalHeight=0}set src(v){this._src=v}get src(){return this._src}}const sandbox={document:doc,Image:Img,console,TextEncoder,TextDecoder,URLSearchParams,location:{search:'',href:'http://localhost/'},navigator:{userAgent:'test'},performance:{now:()=>1000},requestAnimationFrame:()=>1,cancelAnimationFrame:noop,setTimeout:()=>1,clearTimeout:noop,setInterval:()=>1,clearInterval:noop,localStorage:{getItem:()=>null,setItem:noop},addEventListener:(n,f)=>{(events['window:'+n]??=[]).push(f)},removeEventListener:noop,innerWidth:400,innerHeight:800,devicePixelRatio:1,matchMedia:()=>({matches:false,addEventListener:noop}),ResizeObserver:class{observe(){}disconnect(){}}};sandbox.window=sandbox;sandbox.globalThis=sandbox;let context=vm.createContext(sandbox);for(let i=0;i<scripts.length;i++){try{vm.runInContext(scripts[i],context,{filename:'script-'+i+'.js',timeout:15000})}catch(e){console.log('FAIL script',i,e.stack.split('\n').slice(0,5).join('\n'));process.exit(1)}}console.log('PASS boot',scripts.length,'scripts');for(const [id,n] of nodes){if(id==='#soloStart'&&typeof n.onclick==='function'){try{n.onclick({isTrusted:true});console.log('PASS solo start')}catch(e){console.log('FAIL solo start',e.stack.split('\n').slice(0,5).join('\n'));process.exit(1)}}}
for(const id of ['#red','#confirm']){const n=nodes.get(id);if(!n||typeof n.onclick!=='function')throw Error('missing handler '+id);try{n.onclick({isTrusted:true});console.log('PASS click',id)}catch(e){console.log('FAIL click',id,e.stack.split('\n').slice(0,6).join('\n'));process.exit(1)}}
const actual=vm.runInContext('({screenMode,state,choice,round,battleEnvironment})',context);if(actual.screenMode!=='game'||actual.state!=='fight'||actual.choice!==0)throw Error('unexpected gameplay state '+JSON.stringify(actual));console.log('PASS reached battle with environment',actual.battleEnvironment?.fieldId);

for(const im of [...pendingImages]){if(typeof im.onload==='function'){im.complete=true;im.naturalWidth=480;im.naturalHeight=538;try{im.onload()}catch(e){console.log('FAIL deferred image callback',e.stack.split('\n').slice(0,6).join('\n'));process.exit(1)}}}console.log('PASS deferred image callbacks');


for(const zeroPlayer of ['host','guest']){
vm.runInContext(`{
let queue=[],host,guest;const now=()=>1000,o={roomId:'room',sessionId:'session',hostId:'host',members:['host','guest'],now};host=MultiBinding.createWalletSession({...o,userId:'host',send:w=>queue.push(['guest','host',w])});guest=MultiProtocol.createSession({...o,userId:'guest',send:w=>queue.push(['host','guest',w])});const flush=()=>{let n=0;while(queue.length&&n++<10000){const [to,from,w]=queue.shift();(to==='host'?host:guest).receive(from,w)}if(queue.length)throw Error('queue')};guest.hello();host.hello();flush();
const zeroPlayer=ZERO_PLAYER;
function play(n, winner){host.openRound({roundId:n,durationMs:10000,matchup:{units:[]}});flush();let hs=zeroPlayer==='host'?(n<=2?50:0):(n===1?25:n===2?31:39),gs=zeroPlayer==='guest'?(n<=2?50:0):(n===1?25:n===2?31:39);let hside=n<=2&&zeroPlayer==='host'?'A':'B',gside=n<=2&&zeroPlayer==='guest'?'A':'B';if(!host.predict(hside,hs)||!guest.predict(gside,gs))throw Error('prediction rejected');flush();if(host.getState().phase!=='locked')throw Error('round not locked');host.startBattle({engineVersion:'test',ticks:1,winner,events:[],unavailable:'replay-byte-cap'});host.settleRound();host.showResult();flush()}
play(1,'B');play(2,'B');let wallets=host.getState().wallets;if(wallets.find(x=>x.playerId===zeroPlayer).balance!==0||wallets.find(x=>x.playerId===zeroPlayer).terminalReason)throw Error('0 G player incorrectly eliminated');play(3,'B');wallets=host.getState().wallets;if(wallets.find(x=>x.playerId===zeroPlayer).balance!==10)throw Error('0 G recovery failed');if(wallets.find(x=>x.playerId!==zeroPlayer).balance!==195)throw Error('other player settlement failed');
}`.replace('ZERO_PLAYER',JSON.stringify(zeroPlayer)),context);console.log('PASS multiplayer 0 G recovery:',zeroPlayer)
}

vm.runInContext(`{
 const host=MultiBinding.createWalletSession({roomId:'compat',sessionId:'compat-session',hostId:'host',userId:'host',members:['host'],send:()=>{},now:()=>1000});
 const old='d41cbad6946c096c22a3e90b9eb1ed79fec298c299ca3447d08a6d415b9bfebc';
 const wire=MultiProtocol.encode({protocol:MultiProtocol.PROTOCOL,version:1,roomId:'compat',sessionId:'compat-session',type:'hello',contentRevision:old});
 if(host.receive('old-peer',wire)!==false||host.getCompatibilityErrors()['old-peer']!=='content-revision-mismatch')throw Error('old client accepted');
 if(host.getState().participants.includes('old-peer'))throw Error('old client joined');
}`,context);console.log('PASS old-version client rejected before joining');
vm.runInContext(`{
 const host=MultiBinding.createWalletSession({roomId:'high',sessionId:'high-session',hostId:'host',userId:'host',members:['host'],walletConfig:{initialBalance:1000},send:()=>{},now:()=>1000});
 host.openRound({roundId:1,durationMs:10000,matchup:{units:[]}});
 host.predict('A',10);if(host.getState().phase!=='predict'||host.getLedger().currentRound.commits.length)throw Error('legacy amount accepted');
 host.predict('A',250);if(host.getState().phase!=='locked'||host.getLedger().currentRound.commits[0].stake!==250)throw Error('25 percent rejected');
}`,context);console.log('PASS host validates percentage stakes above former cap');

vm.runInContext(`
state='choose';screenMode='game';beginMock();openMultiRound();
if(!document.querySelector('#multiSummary').textContent.includes('確定 0/2人'))throw Error('missing initial ready count');
multiSession.predict('A',25);drainMock();if(!document.querySelector('#multiSummary').textContent.includes('確定 1/2人'))throw Error('missing ready count');
mockGuest.predict('B',25);drainMock();if(!document.querySelector('#multiSummary').textContent.includes('戦闘の準備中'))throw Error('missing locked state');
multiSession.startBattle({engineVersion:'test',ticks:1,winner:'A',events:[],environment:multiSession.getState().environment,unavailable:'replay-byte-cap'});multiSession.settleRound();multiSession.showResult();drainMock();
const results=document.querySelector('#multiResults'),list=document.querySelector('#multiResultsList');if(results.hidden||!list.textContent.includes('あなた：左 25 G · 的中 +25 G')||!list.textContent.includes('参加者2'))throw Error('result list not shown: '+list.textContent);
console.log('PASS mock host/guest states and participant result list on actual DOM update');
`,context);
vm.runInContext("multiSession=null;screenMode='home';syncPersonalResult()",context);if(!nodes.get('#multiResults').hidden)throw Error('multiplayer results leaked into solo');console.log('PASS results hidden after leaving multiplayer');
