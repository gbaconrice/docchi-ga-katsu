from pathlib import Path
import concurrent.futures, json, subprocess, sys, time
root=Path(sys.argv[1]).resolve(); out=Path(sys.argv[2]).resolve(); out.mkdir(parents=True,exist_ok=True)
files=sorted((root/'tests').glob('*.cjs'))
exclude={'map-emote-layout-browser.cjs','integrated-browser.cjs'}
if len(sys.argv)>3: files=[root/'tests'/f for f in sys.argv[3:]]
files=[f for f in files if f.name not in exclude]
def run(f):
 t=time.monotonic()
 try:
  p=subprocess.run(['node',str(f.relative_to(root))],cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
  status='pass' if p.returncode==0 else 'fail'; log=p.stdout; code=p.returncode
 except subprocess.TimeoutExpired as e:
  status='timeout'; log=(e.stdout or b'').decode() if isinstance(e.stdout,bytes) else (e.stdout or ''); code=None
 (out/(f.stem+'.txt')).write_text(log)
 r={'test':f.name,'status':status,'exit':code,'seconds':round(time.monotonic()-t,2)}
 print(json.dumps(r),flush=True); return r
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool: results=list(pool.map(run,files))
(out/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
print('SUMMARY',json.dumps({s:sum(r['status']==s for r in results) for s in ['pass','fail','timeout']}),flush=True)
