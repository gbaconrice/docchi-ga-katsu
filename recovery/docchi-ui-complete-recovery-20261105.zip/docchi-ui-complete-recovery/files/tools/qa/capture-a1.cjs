// Use an authorized browser-capable executor. No remote SDK calls or publication.
// Captures real DOM/controllers with clearly synthetic participant/emoji fixtures.
const fs=require('fs'),path=require('path'),assert=require('assert');const {chromium}=require('playwright');
assert(process.argv[2],'Pass the real A candidate HTML path.');
const source=fs.readFileSync(path.resolve(process.argv[2]),'utf8'),output=path.resolve(process.argv[3]||path.join(__dirname,'screenshots'));fs.mkdirSync(output,{recursive:true});
const fixtures=[{width:320,height:568,shell:'gravity',safe:0,inset:74},{width:375,height:667,shell:'gravity',safe:20,inset:74},{width:390,height:844,shell:'gravity',safe:47,inset:98},{width:390,height:844,shell:'standalone',safe:47,inset:0}];
const launch={headless:true};if(process.env.CHROMIUM_PATH)launch.executablePath=process.env.CHROMIUM_PATH;
async function geometry(page){return page.evaluate(()=>{
 const box=sel=>{const n=document.querySelector(sel),r=n.getBoundingClientRect(),s=getComputedStyle(n);return{left:r.left,top:r.top,right:r.right,bottom:r.bottom,width:r.width,height:r.height,hidden:n.hidden,shadow:s.boxShadow,textShadow:s.textShadow};};
 return{header:box('.game-topline'),fieldLabel:box('#fieldStatus'),roundLabel:box('#status'),wallet:box('.wallet-pill'),coin:box('.wallet-coin'),pause:box('#pause'),left:box('#red'),right:box('#blue'),leftPicks:box('#redPicks'),rightPicks:box('#bluePicks'),confirm:box('#confirm'),rail:box('#participantRailWrap'),field:box('#field'),inspector:box('#crowdInspector'),log:box('#battleLog'),paddingTop:parseFloat(getComputedStyle(document.querySelector('#app')).paddingTop),scrollWidth:document.documentElement.scrollWidth,pickCount:document.querySelectorAll('.prediction-pick').length,participants:document.querySelectorAll('.participant-chip').length,emotes:document.querySelectorAll('.participant-emote:not([hidden])').length};
});}
function noOverlap(a,b,label){assert(a.right<=b.left+1||b.right<=a.left+1||a.bottom<=b.top+1||b.bottom<=a.top+1,label);}
async function installProfiles(page){await page.evaluate(()=>{
 const names=['花子','太郎','すごく長い参加者名の表示確認','葵','蓮','結衣','湊','楓','観戦一','観戦二'];
 multiAdapter={getProfile:id=>({name:names[Number(id.slice(1))-1],avatarUrl:null})};multiUser='preview-viewer';
 window.__previewParticipants=Array.from({length:8},(_,i)=>'u'+(i+1));
 window.__previewPrediction={phase:'predict',participants:window.__previewParticipants,readyIds:['u1','u2','u5','u6'],confirmedSides:[{userId:'u1',side:'A'},{userId:'u2',side:'A'},{userId:'u5',side:'B'},{userId:'u6',side:'B'}],selectedSides:[{userId:'u3',side:'A'},{userId:'u4',side:'A'},{userId:'u7',side:'B'},{userId:'u8',side:'B'}]};
 syncPredictionPicks(window.__previewPrediction);
});}
(async()=>{
 const browser=await chromium.launch(launch),results=[];
 try{for(const f of fixtures){
  const context=await browser.newContext({viewport:{width:f.width,height:f.height},deviceScaleFactor:1,isMobile:true,hasTouch:true}),page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.route('**/*',r=>r.abort());
  const setup=`window.DOCCHI_HOST_LAYOUT={shell:${JSON.stringify(f.shell)}};window.requestAnimationFrame=()=>1;window.cancelAnimationFrame=()=>{};Math.random=(()=>{let s=230511;return()=>{s+=0x6D2B79F5;let t=s;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296;};})();`;
  const html=source.replaceAll('env(safe-area-inset-top, 0px)',f.safe+'px').replace('<head>','<head><script>'+setup+'</script>');
  await page.setContent(html,{waitUntil:'load'});await page.waitForFunction(()=>typeof openSoloScreen==='function');await page.click('#soloStart');await page.click('#red');await installProfiles(page);await page.evaluate(()=>document.activeElement.blur());
  const prefix=f.shell+'-'+f.width,prediction=await geometry(page);assert.equal(prediction.pickCount,8);assert.equal(prediction.paddingTop,Math.max(f.safe,f.inset)+8);assert(prediction.header.top>=prediction.paddingTop-.1);assert(prediction.scrollWidth<=f.width);assert(prediction.confirm.bottom<=f.height+.1);for(const [a,b] of [['fieldLabel','roundLabel'],['roundLabel','wallet'],['wallet','pause']]){assert(prediction[a].right<=prediction[b].left+1,'header order/collision '+a+'/'+b);}assert.equal(prediction.wallet.shadow,'none');assert.equal(prediction.pause.width,44);assert.equal(prediction.coin.width,26);
  for(const side of ['left','right']){const picks=prediction[side+'Picks'],card=prediction[side];assert(picks.left>=card.left&&picks.right<=card.right&&picks.bottom<=card.bottom,'pick icons escaped real card');}
  await page.screenshot({path:path.join(output,prefix+'-prediction-left.png')});await page.click('#blue');await installProfiles(page);await page.evaluate(()=>document.activeElement.blur());await page.screenshot({path:path.join(output,prefix+'-prediction-right.png')});
  // Label/amount stress fixture only. The actual ledger is not changed.
  await page.evaluate(()=>{document.querySelector('#fieldStatus').textContent='長い地図名の表示確認・吹雪の高原・遠距離攻撃低下';document.querySelector('#balance').textContent=walletBalanceText('99999999999999999999');});
  const stress=await geometry(page);for(const [a,b]of [['fieldLabel','roundLabel'],['roundLabel','wallet'],['wallet','pause']])assert(stress[a].right<=stress[b].left+1,'long header collision '+a+'/'+b);assert(stress.scrollWidth<=f.width);assert(stress.header.top>=stress.paddingTop-.1);assert.equal(stress.pause.width,44);
  await page.screenshot({path:path.join(output,prefix+'-header-stress.png')});
  // Start the actual solo controller, then insert rendering-only multiplayer rows.
  await page.evaluate(()=>{multiAdapter=null;multiUser=null;});await page.click('#red');await page.click('#confirm');await page.evaluate(()=>{for(let i=0;i<12&&state==='fight';i++)step(1/60);draw();update();syncCrowdInspector();syncBattleLog(1000);});
  await installProfiles(page);await page.evaluate(()=>{
   multiUser='u1';multiSession={};multiSnapshot={phase:'battle',participants:window.__previewParticipants,spectators:[]};
   syncPredictionPicks({phase:'battle'});window.__previewFeed=window.__previewParticipants.map((sender,i)=>({sender,emoji:['cheer','wow','frustrated','applause'][i%4]}));syncParticipantRail(true,window.__previewFeed);
  });
  const battle=await geometry(page);assert.equal(battle.participants,8);assert.equal(battle.emotes,8);assert.equal(battle.rail.height,40);assert.equal(battle.pause.width,44);assert.equal(battle.pause.height,44);assert(!battle.pause.hidden&&!battle.log.hidden&&!battle.inspector.hidden);assert(battle.pause.top>=battle.paddingTop);noOverlap(battle.wallet,battle.pause,'wallet/pause overlap');noOverlap(battle.rail,battle.field,'participant rail/field overlap');noOverlap(battle.field,battle.inspector,'field/inspector overlap');noOverlap(battle.inspector,battle.log,'inspector/log overlap');assert(battle.scrollWidth<=f.width);
  const firstFour=await page.evaluate(()=>{const rail=document.querySelector('#participantRail'),r=rail.getBoundingClientRect();return{total:rail.children.length,visible:[...rail.children].map((n,i)=>({i,r:n.getBoundingClientRect()})).filter(x=>x.r.left>=r.left-1&&x.r.right<=r.right+1).map(x=>x.i),scrollable:rail.scrollWidth>rail.clientWidth,scrollLeft:rail.scrollLeft};});assert.deepEqual(firstFour.visible,[0,1,2,3]);assert(firstFour.scrollable);
  await page.screenshot({path:path.join(output,prefix+'-battle-first-four.png')});
  await page.evaluate(()=>{const r=document.querySelector('#participantRail');r.scrollLeft=r.scrollWidth;});await page.waitForTimeout(200);await page.evaluate(()=>syncParticipantRail(true,window.__previewFeed));
  const lastFour=await page.evaluate(()=>{const rail=document.querySelector('#participantRail'),r=rail.getBoundingClientRect();return{visible:[...rail.children].map((n,i)=>({i,r:n.getBoundingClientRect()})).filter(x=>x.r.left>=r.left-1&&x.r.right<=r.right+1).map(x=>x.i),scrollLeft:rail.scrollLeft};});assert.deepEqual(lastFour.visible,[4,5,6,7]);assert(lastFour.scrollLeft>firstFour.scrollLeft);await page.screenshot({path:path.join(output,prefix+'-battle-last-four.png')});
  await page.evaluate(()=>{multiSnapshot.spectators=['u9','u10'];syncParticipantRail(true,[...window.__previewFeed,{sender:'u10',emoji:'applause'}]);});await page.screenshot({path:path.join(output,prefix+'-battle-spectators.png')});
  await page.click('#pause');assert(await page.locator('#pausePanel').isVisible());await page.screenshot({path:path.join(output,prefix+'-pause-menu.png')});await page.click('#pauseResume');assert(!(await page.locator('#pausePanel').isVisible()));
  assert.deepEqual(errors,[]);results.push({fixture:f,prediction,stress,battle,firstFour,lastFour,errors,participantsAndReactions:'synthetic rows rendered by actual application controllers'});await context.close();
 }
 fs.writeFileSync(path.join(output,'results.json'),JSON.stringify({actualGameUI:true,realSDK:false,realIOS:false,safeArea:'simulated',results},null,2)+'\n');console.log('PASS A1 header, four-player scrolling and required controls in 28 real UI screenshots');
 }finally{await browser.close();}
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
