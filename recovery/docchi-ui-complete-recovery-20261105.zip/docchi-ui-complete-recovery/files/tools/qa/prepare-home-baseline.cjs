// Only removes the decorative home layer from a separate QA copy.
const fs=require('fs'),path=require('path'),assert=require('assert');
const input=path.resolve(process.argv[2]),output=path.resolve(process.argv[3]);assert.notEqual(input,output);
let html=fs.readFileSync(input,'utf8');
const start=html.indexOf('/* Existing 1024 x 1536 tavern art stays still.');
const marker='#homeScreen .home-light { animation:none !important; }\n}',end=html.indexOf(marker,start);
assert(start>=0&&end>start);html=html.slice(0,start)+html.slice(end+marker.length);
const layer=fs.readFileSync(path.join(__dirname,'home-ambience-original.html'),'utf8').trimEnd();
assert.equal(html.split(layer).length,2);html=html.replace(layer,'');
assert.equal((html.match(/<script id="home-ambience-controller">/g)||[]).length,1);
html=html.replace(/<script id="home-ambience-controller">[\s\S]*?<\/script>/,'');
fs.writeFileSync(output,html);console.log('Created a decoration-free baseline with identical host/header/lobby controls. QA only, not a publishable build.');
