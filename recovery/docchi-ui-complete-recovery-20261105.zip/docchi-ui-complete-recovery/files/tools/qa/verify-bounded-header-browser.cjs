// Run only in an authorized, browser-capable environment. Not run in this cloud.
// Uses synthetic label/amount fixtures; no real SDK/network/publication.
const fs=require('fs'),path=require('path'),assert=require('assert');const {chromium}=require('playwright');
const source=fs.readFileSync(process.argv[2],'utf8'),out=path.resolve(process.argv[3]||'header-checks');fs.mkdirSync(out,{recursive:true});
(async()=>{const browser=await chromium.launch({headless:true,...(process.env.CHROMIUM_PATH?{executablePath:process.env.CHROMIUM_PATH}:{})});const results=[];try{
 for(const [width,height]of [[280,568],[320,568],[375,667],[390,844],[844,390],[1180,800]]){
  const page=await browser.newPage({viewport:{width,height},deviceScaleFactor:1});await page.route('**/*',r=>r.abort());
  await page.setContent(source.replace('<head>','<head><script>window.DOCCHI_HOST_LAYOUT={shell:"gravity",topInsetPx:98};window.requestAnimationFrame=()=>1;window.cancelAnimationFrame=()=>{};</script>'),{waitUntil:'load'});await page.click('#soloStart');
  const sample=()=>page.evaluate(()=>{const rect=s=>{const e=document.querySelector(s),r=e.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height,right:r.right,bottom:r.bottom,scrollHeight:e.scrollHeight,clientHeight:e.clientHeight}};return{header:rect('.game-topline'),field:rect('#fieldStatus'),balance:rect('#balance'),coin:rect('.wallet-coin'),pause:rect('#pause'),pageWidth:document.documentElement.scrollWidth};});
  await page.evaluate(()=>{document.querySelector('#fieldStatus').textContent='草原';document.querySelector('#balance').textContent='100';});const before=await sample();
  for(const digits of [3,6,20,600])for(const hidden of [false,true]){
   await page.evaluate(({digits,hidden})=>{document.querySelector('#fieldStatus').textContent='長い地図名と効果の確認'.repeat(12);document.querySelector('#balance').textContent=walletBalanceText('9'.repeat(digits));document.querySelector('#pause').hidden=hidden;},{digits,hidden});
   const measured=await sample();assert(Math.abs(measured.header.height-before.header.height)<1,'header height changed');assert(measured.balance.height<=44.1&&measured.field.height<=44.1);assert.equal(measured.pause.width,44);assert.equal(measured.pause.height,44);assert.equal(measured.coin.width,26);assert(measured.balance.right<=measured.pause.x+1);assert(measured.field.right<=measured.balance.x+1);assert(measured.pageWidth<=width);
   if(digits===600){assert(measured.balance.scrollHeight>measured.balance.clientHeight);await page.locator('#balance').focus();assert(await page.locator('#balance').evaluate(e=>document.activeElement===e));assert(await page.locator('#balance').evaluate(e=>{e.scrollTop=e.scrollHeight;return e.scrollTop>0&&e.scrollTop+e.clientHeight>=e.scrollHeight-1}));}
   results.push({width,height,digits,hidden,...measured});
  }
  await page.screenshot({path:path.join(out,`${width}x${height}-600-digits.png`)});await page.close();
 }
 fs.writeFileSync(path.join(out,'results.json'),JSON.stringify({realSDK:false,realIOS:false,fixtures:true,results},null,2));console.log('PASS bounded exact text, stable header across pause/result visibility, scroll/focus, narrow/landscape/desktop dimensions.');
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1});
