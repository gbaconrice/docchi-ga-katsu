// Execute only where browser automation is explicitly available and allowed.
// Stops at the first failing step. It never installs software or publishes files.
const fs=require('fs'),path=require('path'),cp=require('child_process');
const root=path.resolve(__dirname,'../..'),html=path.join(root,'index.html'),out=path.resolve(process.argv[2]||path.join(root,'browser-qa'));
fs.mkdirSync(out,{recursive:true});const baseline=path.join(out,'home-baseline.html');
const steps=[
 ['prepare-home-baseline',[path.join(__dirname,'prepare-home-baseline.cjs'),html,baseline]],
 ['battle-result',[path.join(root,'tests/integrated-browser.cjs'),html,path.join(out,'battle-result')]],
 ['header',[path.join(__dirname,'verify-bounded-header-browser.cjs'),html,path.join(out,'header')]],
 ['participants',[path.join(__dirname,'capture-a1.cjs'),html,path.join(out,'participants')]],
 ['lobby',[path.join(__dirname,'capture-lobby.cjs'),html,path.join(out,'lobby')]],
 ['home',[path.join(__dirname,'capture-home.cjs'),html,baseline,path.join(out,'home')]],
];
const results=[];
for(const [name,args]of steps){
 console.log('Checking '+name);const run=cp.spawnSync(process.execPath,args,{cwd:root,encoding:'utf8',maxBuffer:8*1024*1024});
 fs.writeFileSync(path.join(out,name+'.log'),(run.stdout||'')+(run.stderr||'')+(run.error?'\n'+run.error.stack:''));
 results.push({name,exit:run.status,error:run.error?.message||null});fs.writeFileSync(path.join(out,'qa-progress.json'),JSON.stringify({results,realSDK:false,realIOS:false},null,2));
 if(run.status!==0){console.error('Stopped at '+name+'. See its log.');process.exitCode=1;break;}
}
