// Use only in an authorized browser-capable executor. No publication or SDK traffic.
const fs=require('fs'),path=require('path'),assert=require('assert');
const {chromium}=require('playwright');
const html=fs.readFileSync(path.resolve(process.argv[2]||path.join(__dirname,'candidate/index.html')),'utf8');
const out=path.resolve(process.argv[3]||path.join(__dirname,'evidence/browser'));fs.mkdirSync(out,{recursive:true});
const cases=[[320,568,'gravity'],[375,667,'gravity'],[390,844,'gravity'],[390,844,'standalone'],[844,390,'standalone'],[1180,760,'standalone']];
const opts={headless:true};if(process.env.CHROMIUM_PATH)opts.executablePath=process.env.CHROMIUM_PATH;
const fixture=shell=>html.replace('<head>','<head><script>window.DOCCHI_HOST_LAYOUT={shell:'+JSON.stringify(shell)+'};window.requestAnimationFrame=()=>1;window.cancelAnimationFrame=()=>{};<\/script>');
(async()=>{
 const browser=await chromium.launch(opts),results=[];
 try{for(const [width,height,shell] of cases){
  const context=await browser.newContext({viewport:{width,height},deviceScaleFactor:1}),page=await context.newPage(),errors=[];
  page.on('pageerror',e=>errors.push(e.message));await page.route('**/*',r=>r.abort());
  await page.setContent(fixture(shell),{waitUntil:'load'});
  await page.evaluate(()=>{loadNativeSDK=async()=>({room:{getPublicRoomList:async()=>({errno:0,data:{list:[]}})}});});
  const name=shell+'-'+width+'x'+height;
  async function audit(label){
   const snapshot=await page.evaluate(()=>{
    const shadowed=[];for(const n of document.querySelectorAll('#app, #app *')){
     if(!n.getClientRects().length)continue;
     for(const pseudo of [null,'::before','::after']){const s=getComputedStyle(n,pseudo);if(s.boxShadow!=='none'||s.textShadow!=='none'||s.filter.includes('drop-shadow'))shadowed.push({id:n.id,class:n.className,pseudo,box:s.boxShadow,text:s.textShadow,filter:s.filter});}
    }
    const room=document.querySelector('#roomScreen'),r=room.getBoundingClientRect();
    return {shadowed,scrollWidth:document.documentElement.scrollWidth,room:{top:r.top,bottom:r.bottom,height:r.height,scrollHeight:room.scrollHeight},phase:screenMode};
   });assert.deepEqual(snapshot.shadowed,[]);assert(snapshot.scrollWidth<=width,'horizontal overflow');assert.deepEqual(errors,[]);
   await page.screenshot({path:path.join(out,name+'-'+label+'.png')});results.push({name,label,...snapshot});
  }
  await audit('home');await page.click('#showMultiplayer');
  await page.waitForFunction(()=>document.querySelector('#publicRoomsStatus').textContent==='公開ルームはありません。');
  await audit('empty');
  for(const id of ['#createRoom','#joinRoom','#roomId','#refreshPublicRooms','#backHome']){
   const control=page.locator(id);await control.scrollIntoViewIfNeeded();const b=await control.boundingBox();assert(b&&b.height>=44,'tap height '+id);
  }
  await page.evaluate(()=>{loadNativeSDK=async()=>({room:{getPublicRoomList:async()=>({errno:0,data:{list:Array.from({length:8},(_,i)=>({room_id:'友だちの部屋-'+i+'-long-code-123456789',gamer_num:i+1,max_players:8}))}})}});return refreshPublicRooms();});
  await audit('rooms');assert(await page.locator('.public-room-item').last().isDisabled());
  await page.evaluate(()=>{loadNativeSDK=async()=>{throw Error('offline fixture')};return refreshPublicRooms();});
  await audit('offline');assert.match(await page.locator('#publicRoomsStatus').textContent(),/取得できません/);
  await page.locator('#backHome').click();await page.locator('#soloStart').click();
  const before=await page.evaluate(()=>walletState.sessionId);
  await page.evaluate(()=>returnHome());await page.locator('#soloStart').click();
  const after=await page.evaluate(()=>({id:walletState.sessionId,round,balance:currentWallet().balance,state}));
  assert.notEqual(after.id,before);assert.equal(after.round,1);assert.equal(after.balance,100);assert.equal(after.state,'choose');
  await audit('fresh-solo');await context.close();
 }}finally{await browser.close();}
 fs.writeFileSync(path.join(out,'results.json'),JSON.stringify({results,realGravityVerified:false,networkFixturesOnly:true},null,2)+'\n');
 console.log('PASS browser lobby states, no shadows, targets, scrolling and fresh solo entry');
})().catch(e=>{console.error(e);process.exitCode=1});
