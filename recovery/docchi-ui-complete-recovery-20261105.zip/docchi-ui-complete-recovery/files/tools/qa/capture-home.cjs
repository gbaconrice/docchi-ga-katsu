// Run only on an authorized browser-capable executor. No external requests or publication.
const fs=require('fs'),path=require('path'),assert=require('assert');
const {chromium}=require('playwright');
const candidate=fs.readFileSync(path.resolve(process.argv[2]||path.join(__dirname,'candidate/index.html')),'utf8');
const base=fs.readFileSync(path.resolve(process.argv[3]||path.join(__dirname,'../integrated-game-fixes-20261105/candidate/index.html')),'utf8');
const out=path.resolve(process.argv[4]||path.join(__dirname,'evidence/browser'));fs.mkdirSync(out,{recursive:true});
const cases=[[320,568,'gravity'],[375,667,'gravity'],[390,844,'gravity'],[390,844,'standalone'],[844,390,'standalone'],[1180,760,'standalone']];
const opts={headless:true};if(process.env.CHROMIUM_PATH)opts.executablePath=process.env.CHROMIUM_PATH;
const rects=page=>page.evaluate(()=>['#homeScreen','#homeTitle','#soloStart','#showMultiplayer'].map(sel=>{const r=document.querySelector(sel).getBoundingClientRect();return {sel,x:r.x,y:r.y,width:r.width,height:r.height};}));
function fixture(html,shell){return html.replace('<head>','<head><script>window.DOCCHI_HOST_LAYOUT={shell:'+JSON.stringify(shell)+'};window.requestAnimationFrame=()=>1;window.cancelAnimationFrame=()=>{};<\/script>');}
(async()=>{
 const browser=await chromium.launch(opts);const results=[];
 try{for(const [width,height,shell] of cases){
  const context=await browser.newContext({viewport:{width,height},deviceScaleFactor:1,reducedMotion:'no-preference'});
  const basePage=await context.newPage();await basePage.route('**/*',r=>r.abort());
  await basePage.setContent(fixture(base,shell),{waitUntil:'load'});const before=await rects(basePage);await basePage.close();
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.route('**/*',r=>r.abort());
  await page.setContent(fixture(candidate,shell),{waitUntil:'load'});await page.waitForFunction(()=>['running','overflow'].includes(document.querySelector('#homeAmbience').dataset.motion));
  assert.deepEqual(await rects(page),before,'Home/control geometry must be unchanged.');
  const label=shell+'-'+width+'x'+height;
  const state=await page.evaluate(()=>{
   const layer=document.querySelector('#homeAmbience'),plane=layer.firstElementChild,home=document.querySelector('#homeScreen');
   const h=home.getBoundingClientRect(),p=plane.getBoundingClientRect();
   for(const sel of ['#soloStart','#showMultiplayer']){const n=document.querySelector(sel),r=n.getBoundingClientRect();if(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2)!==n)throw Error('Blocked button '+sel);}
   return {motion:layer.dataset.motion,plane:{width:p.width,height:p.height,x:p.x,y:p.y},home:{width:h.width,height:h.height,x:h.x,y:h.y},animations:layer.getAnimations({subtree:true}).length,scrollWidth:document.documentElement.scrollWidth};
  });assert.equal(state.animations,state.motion==='running'?8:0);assert(state.scrollWidth<=width);
  for(const phase of [0,1400,2800]){
   await page.evaluate(t=>{for(const animation of document.querySelector('#homeAmbience').getAnimations({subtree:true})){animation.pause();animation.currentTime=t;}},phase);
   await page.screenshot({path:path.join(out,label+'-phase-'+phase+'.png')});
  }
  await page.click('#showMultiplayer');await page.waitForFunction(()=>document.querySelector('#homeAmbience').dataset.motion==='hidden');
  assert.equal(await page.evaluate(()=>document.querySelector('#homeAmbience').getAnimations({subtree:true}).length),0);
  await page.evaluate(()=>showScreen('home'));await page.waitForFunction(()=>['running','overflow'].includes(document.querySelector('#homeAmbience').dataset.motion));
  await page.emulateMedia({reducedMotion:'reduce'});await page.waitForFunction(()=>['reduced-motion','overflow'].includes(document.querySelector('#homeAmbience').dataset.motion));
  assert.equal(await page.evaluate(()=>document.querySelector('#homeAmbience').getAnimations({subtree:true}).length),0);
  await page.emulateMedia({reducedMotion:'no-preference'});await page.waitForFunction(()=>['running','overflow'].includes(document.querySelector('#homeAmbience').dataset.motion));
  await page.evaluate(()=>{window.DOCCHI_HOME_MOTION={lowPower:true};window.dispatchEvent(new Event('home-motion-change'));});
  assert.equal(await page.evaluate(()=>document.querySelector('#homeAmbience').getAnimations({subtree:true}).length),0);
  await page.evaluate(()=>{window.DOCCHI_HOME_MOTION={};window.dispatchEvent(new Event('home-motion-change'));});
  await page.click('#soloStart');assert(await page.locator('#gameScreen').isVisible());
  await page.evaluate(()=>returnHome());await page.waitForFunction(()=>['running','overflow'].includes(document.querySelector('#homeAmbience').dataset.motion));
  assert.deepEqual(await rects(page),before);assert.deepEqual(errors,[]);results.push({width,height,shell,state,unchangedHomeGeometry:true,errors});await context.close();
 }
 fs.writeFileSync(path.join(out,'results.json'),JSON.stringify({results,actualSDK:false,actualIOS:false,scope:'Real HTML, local browser rendering; no SDK or real-device verification'},null,2));console.log('PASS home: six viewport/host cases, 18 animation phase screenshots, unchanged controls, navigation, reduced motion and low-power host signal.');
 }finally{await browser.close();}
})().catch(error=>{console.error(error.stack);process.exitCode=1;});
